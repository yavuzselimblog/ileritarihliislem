<?php 
    ob_start();
    $db = new PDO("mysql:host=localhost;dbname=ileritarih;charset=utf8;","ileritarih","4~Qk8j0d");

?>